﻿namespace TestGamble
{
    public class Program
    {
        public static void Main(string[] args)
        {
            AllWaySlot allWaySlot = new AllWaySlot(5, 3);
            allWaySlot.MakeRolls(1000000);
        }
    }
}