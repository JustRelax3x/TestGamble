﻿using System;
using System.Collections.Generic;

namespace TestGamble
{
    public class AllWaySlot
    {
        private List<Reel> _reels = new List<Reel>();
        private int _numberOfReels;
        private int[] _rolledNumbers;
        private int _reelHeight;
        private readonly int[] SymbolOfFirstReel = new int[23] { 10, 1, 4, 5, 8, 11, 4, 5, 9, 8, 7, 11, 10, 6, 7, 9, 8, 10, 3, 9, 11, 6, 9 };
        private readonly int[] SymbolOfOtherReel = new int[23] { 6, 1, 3, 8, 7, 6, 9, 11, 2, 8, 4, 5, 10, 11, 4, 10, 8, 7, 9, 11, 5, 10, 9 };
        private readonly int[] _payoutsBySymbolidx3 = new int[11] { 0, 0, 2000, 1000, 1000, 1000, 500, 500, 100, 100, 100 };
        private readonly int[] _payoutsBySymbolidx4 = new int[11] { 0, 0, 10000, 5000, 4000, 2000, 1000, 1000, 500, 500, 500 };
        private readonly int[] _payoutsBySymbolidx5 = new int[11] { 0, 0, 20000, 10000, 6000, 5000, 4000, 4000, 2000, 2000, 2000 };
        private SymbolStats[] SymbolStatistics = new SymbolStats[11] { new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true), new SymbolStats(true) };
        private int _totalWin = 0;
        private int _freeSpinsTriggerCount = 0;
        private int[] _freeSpinsCountbyLevel = new int[3] { 0, 0, 0 };

        public AllWaySlot(int numberOfReels, int reelHeight)
        {
            _numberOfReels = numberOfReels;
            _reelHeight = reelHeight;
            _reels.Add(new Reel(SymbolOfFirstReel));
            for (int i = 1; i < _numberOfReels; i++)
                _reels.Add(new Reel(SymbolOfOtherReel));
            _rolledNumbers = new int[_numberOfReels];
        }

        public void MakeRolls(int numberOfRolls)
        {
            for (int i = 0; i < numberOfRolls; i++)
            {
                MakeRoll();
                AnalyzeRoll();
                CheckFreeSpins();
            }
            PrintStats(numberOfRolls);
        }

        private void MakeRoll()
        {
            for (int i = 0; i < _numberOfReels; i++)
            {
                _rolledNumbers[i] = _reels[i].RandomReelPosition();
            }
        }

        private void AnalyzeRoll()
        {
            int k = 0;
            while (k < _reelHeight)
            {
                int symbolId = _reels[0].GetSymbolId(_rolledNumbers[0] + k) - 1;
                int lastReelNumber = 0, amount = 1;
                while (FindSymbolOnReel(symbolId, lastReelNumber) > 0)
                {
                    if (lastReelNumber == 0) amount = 1;
                    else amount *= FindSymbolOnReel(symbolId, lastReelNumber);
                    lastReelNumber++;
                }
                lastReelNumber--;
                SaveStats(symbolId, amount, lastReelNumber);
                k++;
            }
        }

        private int FindSymbolOnReel(int symbolId, int reelNumber)
        {
            if (reelNumber >= _numberOfReels) return 0;
            int count = 0;
            for (int i = 0; i < _reelHeight; i++)
            {
                if (symbolId == _reels[reelNumber].GetSymbolId(_rolledNumbers[reelNumber] + i) - 1 || (_reels[reelNumber].GetSymbolId(_rolledNumbers[reelNumber] + i) == 2 && symbolId != 0))
                    count++;
            }
            return count;
        }

        private void CheckFreeSpins()
        {
            int symbolId = 0, counter = 0;
            for (int i = 0; i < _numberOfReels; i++)
            {
                counter += FindSymbolOnReel(symbolId, i);
            }
            if (counter <= 2) return;
            _freeSpinsTriggerCount++;
            _freeSpinsCountbyLevel[counter - 3]++;
        }

        private void SaveStats(int symbolId, int amount, int lastReelNumber)
        {
            if (lastReelNumber < 0) return;
            SymbolStatistics[symbolId].AddAmount(lastReelNumber, amount);
            if (lastReelNumber <= 1) return;
            else if (lastReelNumber == 2) _totalWin += amount * _payoutsBySymbolidx3[symbolId];
            else if (lastReelNumber == 3) _totalWin += amount * _payoutsBySymbolidx4[symbolId];
            else if (lastReelNumber == 4) _totalWin += amount * _payoutsBySymbolidx5[symbolId];
        }

        private void PrintStats(int numberOfRolls)
        {
            for (int i = 1; i < _payoutsBySymbolidx3.Length; i++)
            {
                Console.WriteLine(" ");
                Console.WriteLine("Symbol: " + (i + 1));
                for (int j = 0; j < _numberOfReels; j++)
                {
                    Console.Write(" | x" + (j + 1) + ": " + SymbolStatistics[i].GetAmount(j) / (float)numberOfRolls);
                }
            }
            Console.WriteLine(" \n");
            Console.WriteLine("Total win: " + _totalWin);
            Console.WriteLine("Total spend: " + numberOfRolls * 1000);
            Console.WriteLine("per spin: " + _totalWin / 10f / numberOfRolls + "%" + "   per spin: " + _totalWin / (float)numberOfRolls + " money");
            Console.WriteLine("free spins triggers: " + _freeSpinsTriggerCount + "	frequency: " + _freeSpinsTriggerCount / (float)numberOfRolls);
            Console.WriteLine("3scatter: " + _freeSpinsCountbyLevel[0] / (float)numberOfRolls + " 4scatters: " + _freeSpinsCountbyLevel[1] / (float)numberOfRolls + " 5scatters: " + _freeSpinsCountbyLevel[2] / (float)numberOfRolls);
            Console.WriteLine("Amount of free spins/spin: " + (_freeSpinsCountbyLevel[0] * 6 + _freeSpinsCountbyLevel[1] * 8 + _freeSpinsCountbyLevel[2] * 10) / (float)numberOfRolls);
        }
    }
}