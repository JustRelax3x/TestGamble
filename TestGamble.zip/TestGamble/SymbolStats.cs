﻿namespace TestGamble
{
    public struct SymbolStats
    {
        private const int ReelsMaxNumber = 5;
        private readonly int[] AmountXi;

        public SymbolStats(bool flag)
        {
            AmountXi = new int[ReelsMaxNumber];
            for (int i = 0; i < ReelsMaxNumber; i++)
            {
                AmountXi[i] = 0;
            }
        }

        public void AddAmount(int lastReel, int amount)
        {
            AmountXi[lastReel] += amount;
        }

        public int GetAmount(int lastReel)
        {
            return AmountXi[lastReel];
        }
    }
}