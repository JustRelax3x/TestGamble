﻿
namespace TestGamble
{
    public class Reel
    {
        private int[] _symbolsId;
        private Random random = new Random();

        public int Length => _symbolsId.Length;

        public Reel(int[] symbolsId)
        {
            _symbolsId = symbolsId;
        }

        public int RandomReelPosition()
        {
            return random.Next(0, Length);
        }

        public int GetSymbolId(int number)
        {
            if (number < 0) number += Length;
            return _symbolsId[number % Length];
        }
    }
}